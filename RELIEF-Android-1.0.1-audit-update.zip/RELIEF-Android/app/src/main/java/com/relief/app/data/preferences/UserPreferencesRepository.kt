package com.relief.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.relief.app.data.model.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "relief_prefs")

data class UserSettings(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val hasCompletedOnboarding: Boolean = false,
    val fontScale: Float = 1.0f,
    val showTransliteration: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("app_language")
        val ONBOARDED = booleanPreferencesKey("has_completed_onboarding")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val SHOW_TRANSLITERATION = booleanPreferencesKey("show_transliteration")
    }

    val settings: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val langCode = prefs[Keys.LANGUAGE] ?: AppLanguage.ENGLISH.code
        val language = AppLanguage.entries.firstOrNull { it.code == langCode } ?: AppLanguage.ENGLISH
        UserSettings(
            language = language,
            hasCompletedOnboarding = prefs[Keys.ONBOARDED] ?: false,
            fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
            showTransliteration = prefs[Keys.SHOW_TRANSLITERATION] ?: true
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun completeOnboarding() {
        context.dataStore.edit { it[Keys.ONBOARDED] = true }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[Keys.FONT_SCALE] = scale.coerceIn(0.85f, 1.4f) }
    }

    suspend fun setShowTransliteration(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_TRANSLITERATION] = enabled }
    }
}
