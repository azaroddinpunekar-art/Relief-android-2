package com.relief.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.relief.app.data.local.entity.BookEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.ScriptureType
import com.relief.app.ui.components.PassageCard
import com.relief.app.ui.components.ReliefCard
import com.relief.app.ui.components.ReliefTopBar
import com.relief.app.ui.theme.DeepObsidian
import com.relief.app.ui.theme.MetallicGold
import com.relief.app.ui.theme.MutedGoldBorder
import com.relief.app.ui.theme.WarmGrey
import com.relief.app.ui.theme.WarmWhite

@Composable
fun ScripturesHubScreen(
    language: AppLanguage,
    onOpenQuran: () -> Unit,
    onOpenGita: () -> Unit
) {
    val isHi = language == AppLanguage.HINDI
    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) "पवित्र ग्रंथ" else "Sacred Scriptures") }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ReliefCard(onClick = onOpenQuran) {
                    Text(if (isHi) "क़ुरआन मजीद" else "The Noble Quran", style = MaterialTheme.typography.titleLarge, color = WarmWhite)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("114 Surahs · 6,236 Ayahs · Arabic RTL, English & Hindi", style = MaterialTheme.typography.bodyMedium, color = MetallicGold)
                }
            }
            item {
                ReliefCard(onClick = onOpenGita) {
                    Text(if (isHi) "श्रीमद्भगवद्गीता" else "Bhagavad Gita", style = MaterialTheme.typography.titleLarge, color = WarmWhite)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("18 Chapters · 700 Shlokas · Sanskrit, English & Hindi", style = MaterialTheme.typography.bodyMedium, color = MetallicGold)
                }
            }
        }
    }
}

@Composable
fun ScriptureLibraryScreen(
    scripture: ScriptureType,
    language: AppLanguage,
    books: List<BookEntity>,
    onBack: () -> Unit,
    onOpenBook: (BookEntity) -> Unit
) {
    val isHi = language == AppLanguage.HINDI
    val title = when (scripture) {
        ScriptureType.QURAN -> if (isHi) "क़ुरआन पुस्तकालय (114 सूरह)" else "Quran Library"
        ScriptureType.GITA -> if (isHi) "भगवद्गीता पुस्तकालय (18 अध्याय)" else "Bhagavad Gita Library"
        ScriptureType.BIBLE -> if (isHi) "उपलब्ध नहीं" else "Not available"
    }

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = title, onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (books.isEmpty()) {
                item {
                    ReliefCard {
                        Text(
                            text = if (isHi) "डेटासेट अभी आयात नहीं हुआ है" else "Dataset Not Yet Imported",
                            style = MaterialTheme.typography.titleMedium,
                            color = MetallicGold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Expected ${scripture.expectedBooksOrSurahs} books/surahs (${scripture.expectedPassages} passages). Import verified JSON in Profile → Offline Datasets.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmGrey
                        )
                    }
                }
            } else {
                items(books, key = { it.id }) { book ->
                    ReliefCard(onClick = { onOpenBook(book) }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${book.bookNumber}. ${if (isHi && book.nameHindi.isNotBlank()) book.nameHindi else book.nameEnglish}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = WarmWhite
                                )
                                if (book.nameOriginal.isNotBlank()) {
                                    Text(
                                        text = book.nameOriginal,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MetallicGold
                                    )
                                }
                            }
                            Text(
                                text = "${book.importedVerseCount} verses",
                                style = MaterialTheme.typography.labelMedium,
                                color = WarmGrey
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScriptureReaderScreen(
    scripture: ScriptureType,
    bookNumber: Int,
    initialChapter: Int,
    maxChapters: Int,
    language: AppLanguage,
    fontScale: Float,
    showTransliteration: Boolean,
    passages: List<PassageEntity>,
    bookmarkIds: List<String>,
    onChapterChange: (Int) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onRecordReading: (String) -> Unit,
    onBack: () -> Unit
) {
    var currentChapter by remember(bookNumber, initialChapter) { mutableIntStateOf(initialChapter) }
    val isHi = language == AppLanguage.HINDI

    LaunchedEffect(passages.firstOrNull()?.id) {
        passages.firstOrNull()?.let { onRecordReading(it.id) }
    }

    val headerTitle = passages.firstOrNull()?.let {
        val name = if (isHi && it.bookOrSurahHindi.isNotBlank()) it.bookOrSurahHindi else it.bookOrSurah
        "$name · Ch. $currentChapter"
    } ?: "${scripture.displayNameEn} · $bookNumber:$currentChapter"

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = headerTitle, onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(passages, key = { it.id }) { passage ->
                PassageCard(
                    passage = passage,
                    language = language,
                    fontScale = fontScale,
                    isBookmarked = bookmarkIds.contains(passage.id),
                    onToggleBookmark = { onToggleBookmark(passage.id) },
                    showTransliteration = showTransliteration
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (currentChapter > 1) {
                                currentChapter -= 1
                                onChapterChange(currentChapter)
                            }
                        },
                        enabled = currentChapter > 1,
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, MutedGoldBorder)
                    ) {
                        Text(if (isHi) "पिछला अध्याय" else "Previous", color = WarmWhite)
                    }
                    OutlinedButton(
                        onClick = {
                            if (currentChapter < maxChapters) {
                                currentChapter += 1
                                onChapterChange(currentChapter)
                            }
                        },
                        enabled = currentChapter < maxChapters,
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, MutedGoldBorder)
                    ) {
                        Text(if (isHi) "अगला अध्याय" else "Next", color = WarmWhite)
                    }
                }
            }
        }
    }
}
