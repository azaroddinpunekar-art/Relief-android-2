package com.relief.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.relief.app.data.model.ScriptureType

@Entity(
    tableName = "books",
    indices = [Index(value = ["scripture", "bookNumber"], unique = true)]
)
data class BookEntity(
    @PrimaryKey val id: String,
    val scripture: ScriptureType,
    val bookNumber: Int,
    val nameEnglish: String,
    val nameOriginal: String,
    val nameHindi: String,
    val sectionOrType: String,
    val chapterCount: Int,
    val expectedVerseCount: Int,
    val importedVerseCount: Int
)

@Entity(
    tableName = "passages",
    indices = [
        Index(value = ["scripture", "bookNumber", "chapterNumber", "verseNumber"], unique = true),
        Index(value = ["scripture", "bookNumber", "chapterNumber"])
    ]
)
data class PassageEntity(
    @PrimaryKey val id: String,
    val scripture: ScriptureType,
    val bookNumber: Int,
    val bookOrSurah: String,
    val bookOrSurahOriginal: String,
    val bookOrSurahHindi: String,
    val chapterNumber: Int,
    val verseNumber: Int,
    val originalText: String,
    val transliteration: String = "",
    val englishText: String,
    val hindiText: String,
    val translationEdition: String,
    val source: String,
    val license: String
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val passageId: String,
    val note: String = "",
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "reading_history")
data class ReadingHistoryEntity(
    @PrimaryKey val passageId: String,
    val viewedAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "import_audits")
data class ImportAuditEntity(
    @PrimaryKey val scripture: ScriptureType,
    val expectedBooksOrSurahs: Int,
    val importedBooksOrSurahs: Int,
    val expectedPassages: Int,
    val importedPassages: Int,
    val originalCoverage: Int,
    val englishCoverage: Int,
    val hindiCoverage: Int,
    val duplicateRejected: Int,
    val isComplete: Boolean,
    val missingRecordsSummary: String,
    val updatedAtEpochMs: Long
)
