package com.relief.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.relief.app.data.local.dao.BookmarkDao
import com.relief.app.data.local.dao.HistoryDao
import com.relief.app.data.local.dao.ImportAuditDao
import com.relief.app.data.local.dao.PassageDao
import com.relief.app.data.local.entity.BookEntity
import com.relief.app.data.local.entity.BookmarkEntity
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.local.entity.ReadingHistoryEntity
import com.relief.app.data.model.ScriptureType

class ReliefTypeConverters {
    @TypeConverter
    fun fromScriptureType(value: ScriptureType): String = value.name

    @TypeConverter
    fun toScriptureType(value: String): ScriptureType = ScriptureType.valueOf(value)
}

@Database(
    entities = [
        BookEntity::class,
        PassageEntity::class,
        BookmarkEntity::class,
        ReadingHistoryEntity::class,
        ImportAuditEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(ReliefTypeConverters::class)
abstract class ReliefDatabase : RoomDatabase() {
    abstract fun passageDao(): PassageDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao
    abstract fun importAuditDao(): ImportAuditDao

    companion object {
        @Volatile
        private var INSTANCE: ReliefDatabase? = null

        fun getInstance(context: Context): ReliefDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ReliefDatabase::class.java,
                    "relief_scriptures.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
