package com.relief.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.ScriptureType
import com.relief.app.ui.screens.AboutSourcesScreen
import com.relief.app.ui.screens.BookmarksScreen
import com.relief.app.ui.screens.CrossReligiousComparisonScreen
import com.relief.app.ui.screens.HomeDashboardScreen
import com.relief.app.ui.screens.LanguageSelectorScreen
import com.relief.app.ui.screens.LifeSituationsScreen
import com.relief.app.ui.screens.ProfileSettingsScreen
import com.relief.app.ui.screens.ReadingHistoryScreen
import com.relief.app.ui.screens.ScriptureLibraryScreen
import com.relief.app.ui.screens.ScriptureReaderScreen
import com.relief.app.ui.screens.ScripturesHubScreen
import com.relief.app.ui.screens.SituationDetailScreen
import com.relief.app.ui.screens.SplashScreen
import com.relief.app.ui.screens.UniversalSearchScreen
import com.relief.app.ui.screens.WelcomeScreen
import com.relief.app.ui.theme.CharcoalSurface
import com.relief.app.ui.theme.DeepObsidian
import com.relief.app.ui.theme.MetallicGold
import com.relief.app.ui.theme.WarmGrey
import com.relief.app.ui.viewmodel.ReliefViewModel

@Composable
fun ReliefNavHost(viewModel: ReliefViewModel) {
    val navController = rememberNavController()
    val settings by viewModel.settings.collectAsState()
    val quranBooks by viewModel.quranBooks.collectAsState()
    val gitaBooks by viewModel.gitaBooks.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val bookmarkIds by viewModel.bookmarkIds.collectAsState()
    val readingHistory by viewModel.readingHistory.collectAsState()
    val importAudits by viewModel.importAudits.collectAsState()
    val dailyWisdom by viewModel.dailyWisdom.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val importStatus by viewModel.importStatusMessage.collectAsState()
    val assistantResponse by viewModel.assistantResponse.collectAsState()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = BottomNavTab.entries.any { it.route == currentRoute }

    Scaffold(
        containerColor = DeepObsidian,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = CharcoalSurface) {
                    BottomNavTab.entries.forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.labelEn) },
                            label = {
                                Text(if (settings.language == AppLanguage.HINDI) tab.labelHi else tab.labelEn)
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MetallicGold,
                                selectedTextColor = MetallicGold,
                                unselectedIconColor = WarmGrey,
                                unselectedTextColor = WarmGrey,
                                indicatorColor = DeepObsidian
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = ReliefRoute.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(ReliefRoute.Splash.route) {
                SplashScreen(
                    onFinished = {
                        val next = if (settings.hasCompletedOnboarding) {
                            ReliefRoute.Home.route
                        } else {
                            ReliefRoute.Welcome.route
                        }
                        navController.navigate(next) {
                            popUpTo(ReliefRoute.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(ReliefRoute.Welcome.route) {
                WelcomeScreen(
                    language = settings.language,
                    onContinue = { navController.navigate(ReliefRoute.LanguageSelector.route) }
                )
            }

            composable(ReliefRoute.LanguageSelector.route) {
                LanguageSelectorScreen(
                    selectedLanguage = settings.language,
                    onSelectLanguage = viewModel::setLanguage,
                    onContinue = {
                        viewModel.completeOnboarding()
                        navController.navigate(ReliefRoute.Home.route) {
                            popUpTo(ReliefRoute.Welcome.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(ReliefRoute.Home.route) {
                HomeDashboardScreen(
                    language = settings.language,
                    fontScale = settings.fontScale,
                    dailyWisdom = dailyWisdom,
                    bookmarkIds = bookmarkIds,
                    situations = viewModel.getAllSituations(),
                    audits = importAudits,
                    onToggleBookmark = viewModel::toggleBookmark,
                    onOpenSearch = { navController.navigate(ReliefRoute.Search.route) },
                    onOpenHistory = { navController.navigate(ReliefRoute.ReadingHistory.route) },
                    onOpenScriptures = { navController.navigate(ReliefRoute.ScripturesHub.route) },
                    onOpenSituation = { navController.navigate(ReliefRoute.SituationDetail.create(it)) },
                    onOpenComparison = { navController.navigate(ReliefRoute.CrossReligiousComparison.create(it)) },
                    onOpenAbout = { navController.navigate(ReliefRoute.AboutSources.route) }
                )
            }

            composable(ReliefRoute.ScripturesHub.route) {
                ScripturesHubScreen(
                    language = settings.language,
                    onOpenQuran = { navController.navigate(ReliefRoute.QuranLibrary.route) },
                    onOpenGita = { navController.navigate(ReliefRoute.GitaLibrary.route) }
                )
            }

            composable(ReliefRoute.QuranLibrary.route) {
                ScriptureLibraryScreen(
                    scripture = ScriptureType.QURAN,
                    language = settings.language,
                    books = quranBooks,
                    onBack = { navController.popBackStack() },
                    onOpenBook = { book ->
                        navController.navigate(ReliefRoute.Reader.create(ScriptureType.QURAN.name, book.bookNumber, book.bookNumber))
                    }
                )
            }

            composable(ReliefRoute.GitaLibrary.route) {
                ScriptureLibraryScreen(
                    scripture = ScriptureType.GITA,
                    language = settings.language,
                    books = gitaBooks,
                    onBack = { navController.popBackStack() },
                    onOpenBook = { book ->
                        navController.navigate(ReliefRoute.Reader.create(ScriptureType.GITA.name, book.bookNumber, book.bookNumber))
                    }
                )
            }

            composable(
                route = ReliefRoute.Reader.route,
                arguments = listOf(
                    navArgument("scripture") { type = NavType.StringType },
                    navArgument("bookNumber") { type = NavType.IntType },
                    navArgument("chapterNumber") { type = NavType.IntType }
                )
            ) { entry ->
                val scripture = ScriptureType.valueOf(entry.arguments?.getString("scripture") ?: ScriptureType.QURAN.name)
                val bookNumber = entry.arguments?.getInt("bookNumber") ?: 1
                val chapterNumber = entry.arguments?.getInt("chapterNumber") ?: 1
                val passages by viewModel.observeChapter(scripture, bookNumber, chapterNumber)
                    .collectAsState(initial = emptyList())
                val maxChapters = when (scripture) {
                    ScriptureType.QURAN -> 114
                    ScriptureType.GITA -> 18
                    ScriptureType.BIBLE -> 1 // Legacy database value; not exposed in the app.
                }

                ScriptureReaderScreen(
                    scripture = scripture,
                    bookNumber = bookNumber,
                    initialChapter = chapterNumber,
                    maxChapters = maxChapters,
                    language = settings.language,
                    fontScale = settings.fontScale,
                    showTransliteration = settings.showTransliteration,
                    passages = passages,
                    bookmarkIds = bookmarkIds,
                    onChapterChange = { nextChapter ->
                        val nextBook = nextChapter
                        navController.navigate(ReliefRoute.Reader.create(scripture.name, nextBook, nextChapter)) {
                            popUpTo(ReliefRoute.Reader.route) { inclusive = true }
                        }
                    },
                    onToggleBookmark = viewModel::toggleBookmark,
                    onRecordReading = viewModel::recordReading,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(ReliefRoute.Situations.route) {
                LifeSituationsScreen(
                    language = settings.language,
                    situations = viewModel.getAllSituations(),
                    onSelectSituation = { navController.navigate(ReliefRoute.SituationDetail.create(it)) }
                )
            }

            composable(
                route = ReliefRoute.SituationDetail.route,
                arguments = listOf(navArgument("situationId") { type = NavType.StringType })
            ) { entry ->
                val spec = viewModel.getSituation(entry.arguments?.getString("situationId") ?: "")
                    ?: viewModel.getAllSituations().first()
                SituationDetailScreen(
                    spec = spec,
                    language = settings.language,
                    fontScale = settings.fontScale,
                    bookmarkIds = bookmarkIds,
                    loadPassages = viewModel::loadPassagesByIds,
                    onToggleBookmark = viewModel::toggleBookmark,
                    onOpenComparison = { navController.navigate(ReliefRoute.CrossReligiousComparison.create(it)) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = ReliefRoute.CrossReligiousComparison.route,
                arguments = listOf(navArgument("situationId") { type = NavType.StringType })
            ) { entry ->
                val spec = viewModel.getSituation(entry.arguments?.getString("situationId") ?: "")
                    ?: viewModel.getAllSituations().first()
                CrossReligiousComparisonScreen(
                    spec = spec,
                    language = settings.language,
                    loadPassages = viewModel::loadPassagesByIds,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(ReliefRoute.Search.route) {
                UniversalSearchScreen(
                    language = settings.language,
                    fontScale = settings.fontScale,
                    results = searchResults,
                    bookmarkIds = bookmarkIds,
                    assistantResponse = assistantResponse,
                    onSearch = viewModel::search,
                    onAskAssistant = viewModel::askWisdomAssistant,
                    onToggleBookmark = viewModel::toggleBookmark,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(ReliefRoute.Bookmarks.route) {
                BookmarksScreen(
                    language = settings.language,
                    fontScale = settings.fontScale,
                    bookmarks = bookmarks,
                    onToggleBookmark = viewModel::toggleBookmark
                )
            }

            composable(ReliefRoute.ReadingHistory.route) {
                ReadingHistoryScreen(
                    language = settings.language,
                    fontScale = settings.fontScale,
                    history = readingHistory,
                    bookmarkIds = bookmarkIds,
                    onToggleBookmark = viewModel::toggleBookmark,
                    onClearHistory = viewModel::clearHistory,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(ReliefRoute.Profile.route) {
                ProfileSettingsScreen(
                    settings = settings,
                    importStatusMessage = importStatus,
                    onSetLanguage = viewModel::setLanguage,
                    onSetFontScale = viewModel::setFontScale,
                    onSetTransliteration = viewModel::setShowTransliteration,
                    onImportDataset = viewModel::importDataset,
                    onOpenHistory = { navController.navigate(ReliefRoute.ReadingHistory.route) },
                    onOpenAbout = { navController.navigate(ReliefRoute.AboutSources.route) }
                )
            }

            composable(ReliefRoute.AboutSources.route) {
                AboutSourcesScreen(
                    audits = importAudits,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
