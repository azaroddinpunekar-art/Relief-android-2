# RELIEF Technical Audit

## Supported scripture libraries
- Quran: bundled dataset retained.
- Bhagavad Gita: bundled dataset retained.
- Bible: removed from the application bundle and all user-facing screens at the owner's request.

The app imports and displays only Quran and Bhagavad Gita datasets. The legacy enum value is retained internally only to avoid breaking existing local database records during upgrades.
